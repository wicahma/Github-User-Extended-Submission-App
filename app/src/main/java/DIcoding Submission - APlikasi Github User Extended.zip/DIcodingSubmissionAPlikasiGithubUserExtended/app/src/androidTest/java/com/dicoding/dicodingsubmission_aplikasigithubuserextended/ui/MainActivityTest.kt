package com.dicoding.dicodingsubmission_aplikasigithubuserextended.ui

import org.junit.jupiter.api.Assertions.*
import org.junit.runner.RunWith

class MainActivityTest {

}