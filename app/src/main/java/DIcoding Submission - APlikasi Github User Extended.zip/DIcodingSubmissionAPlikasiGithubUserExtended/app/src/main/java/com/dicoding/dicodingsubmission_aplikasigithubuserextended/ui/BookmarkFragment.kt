package com.dicoding.dicodingsubmission_aplikasigithubuserextended.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.findNavController
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.data.local.entity.UserEntity
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.databinding.FragmentBookmarkBinding
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.utils.Event
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.utils.SettingPreferences
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.utils.dataStore
import com.google.android.material.snackbar.Snackbar

class BookmarkFragment : Fragment() {

    private var _binding: FragmentBookmarkBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBookmarkBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val pref = SettingPreferences.getInstance(requireActivity().dataStore)
        val factory: ViewModelFactory = ViewModelFactory.getInstance(requireActivity(), pref)
        val bookmarkViewModel: BookmarkViewModel by viewModels { factory }

        bookmarkViewModel.getBookmarkedUser().observe(viewLifecycleOwner) { bookmarkedUser ->
            setUserListData(bookmarkedUser, bookmarkViewModel)
        }
    }

    private fun setUserListData(userResponse: List<UserEntity>, viewModel: BookmarkViewModel) {
        val adapter = UserListAdapter(this)
        adapter.submitList(userResponse)
        binding.rvBookmark.adapter = adapter

        adapter.setOnItemClickCallback(object : UserListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: UserEntity, view: View) {
                val toUserDetailFragment =
                    BookmarkFragmentDirections.actionBookmarkFragmentToUserDetailFragment(
                        data.avatar_url,
                        data.login
                    )
                view.findNavController().navigate(toUserDetailFragment)
            }
        })

        adapter.setOnItemBookmarkCallback(object : UserListAdapter.OnBookmarkLongPressCallback {
            override fun onItemLongPressed(data: UserEntity, view: View) {
                if (data.isBookmarked) {
                    viewModel.deleteUser(data)
                    setSnackBar(Event("Bookmark berhasil dihapus!"))
                } else {
                    viewModel.saveUser(data)
                }
            }

        })
    }

    private fun setSnackBar(e: Event<String>) {
        e.getContentIfNotHandled()?.let {
            Snackbar.make(requireView(), it, Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }


}