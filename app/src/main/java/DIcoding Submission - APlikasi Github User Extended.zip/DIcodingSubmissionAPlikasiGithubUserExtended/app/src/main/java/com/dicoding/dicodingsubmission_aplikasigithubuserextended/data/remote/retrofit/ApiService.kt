package com.dicoding.dicodingsubmission_aplikasigithubuserextended.data.remote.retrofit

import com.dicoding.dicodingsubmission_aplikasigithubuserextended.BuildConfig
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.data.remote.response.User
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.data.remote.response.UserDetailResponse
import com.dicoding.dicodingsubmission_aplikasigithubuserextended.data.remote.response.UserSearchResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: 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")
    fun searchUsers(@Query("q") username: String): Call<UserSearchResponse>

    @GET("users")
    @Headers("Authorization: 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")
    fun getAllUsers(): Call<List<User>>

    @GET("users/{username}")
    @Headers("Authorization: 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")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<UserDetailResponse>

    @GET("users/{username}/following")
    @Headers("Authorization: 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")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<List<User>>

    @GET("users/{username}/followers")
    @Headers("Authorization: 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")
    fun getUserFollowers(
        @Path("username") username: String
    ): Call<List<User>>
}